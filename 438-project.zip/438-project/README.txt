STUDENTS:
	Nawaf Al-Dhelaan naldhel1@jhu.edu
	Christopher Le christophertnle@gmail.com
	Richard Liu liu.richard0@gmail.com
	Kyle Verdeyen kverdey1@jhu.edu

README.TXT: 
-----------

The top directory (project/) contains the source files for our models, as well as the process.sh, train_model.sh, and test_model.sh. Please look at those files as they have comments to help you run the code.

The (results/) directory will contain our .png files once the pipeline is executed.
The (data/) directory contains the dataset used, as well as data cleaning scripts in-case you want to reproduce a preprocessed dataset using raw data from HapMap.


PREPROCESSING: 
-------------

The original dataset is huge (~6GB), and our preprocessing is mostly just cleaning that dataset and performing reductions on it (read report for more info). 
The preprocessing takes a while, so we've made a preprocessed dataset available in-case you don't want to go through the whole preprocessing pipeline yourself. We've also given instructions on how to run the preprocessing pipeline if you want to do that instead.
All of that information is in the process_data.sh file. Please read the comments in the file before you run it. Note that if you want to preprocess, you'll need a utility tool called PLINK (If you have homebrew, do "brew install plink")


TRAINING: 
---------

The NN models (SOM and Autoencoder) require unique packages. See download_dependencies.sh for which packages are needed. This file isn't called by any of the other scripts, so you'll have to run it
If you want to install the packages and run the SOM and autoencoder code.
The Autoencoder takes a really long time to train, so we've included parameters (printed in .csv files) and a trained model (saved in disk) that you can load and run data on. 
The files containing the saved model, and the parameters, are huge. So we couldn't include them in our email submission. 
The dropbox link: https://www.dropbox.com/sh/q7rwt6os4owblx6/AAA6yJN9uXk2f4ezZllaRwsAa?dl=0
It contains
	1. A trained model saved to disk
	2. Printed parameters in csv files
	3. Instructions on how to run the autoencoder
	4. Diagrams produced by the autoencoder


The SOM model also takes a while (I think an hour), but it's more bothersome since it doesn't easily allow you to save models to disk, and also has no way of giving you "parameters" for the model. You'll have to run it to produce its result. We were unable to complete the computation to save the codebook matrix in time for this submission, but our results should be reproduceable with the given code. 

The Manifold learning approaches (i.e. the rest of the models) all use common libraries, and run adequately fast enough.

TESTING: 
-------

Since this is essentially a clustering task, we're evaluating the models visually. All of the model files produce diagrams (.png files). Running test_models.sh moves these images to the (results/) directory.