# Student: Nawaf Al-Dhelaan
# Course: 600.438
# Date: April 7th, 2017

# =========================== Dependencies ===========================

from __future__ import division    # In case you run with python2

from sklearn.manifold import Isomap
from sklearn import preprocessing
import matplotlib.pyplot as plt
import numpy as np
import sys, math

# =========================== Auxilary Functions ===========================
	
# Makes a scatter plot for two PCs. Used in part 3
# I put it in a function to make things neater
def load_plot(population_data, coord, title):
	# Indices - useful for fast computation
	asw_indices = np.where(population_data == 1)
	ceu_indices = np.where(population_data == 2)
	chb_indices = np.where(population_data == 3)
	chd_indices = np.where(population_data == 4)
	gih_indices = np.where(population_data == 5)
	jpt_indices = np.where(population_data == 6)
	lwk_indices = np.where(population_data == 7)
	mex_indices = np.where(population_data == 8)
	mkk_indices = np.where(population_data == 9)
	tsi_indices = np.where(population_data == 10)
	yri_indices = np.where(population_data == 11)
	n = 11
	colors = 2 * np.pi * np.random.rand(n)
	asw_coord = coord[asw_indices].T
	ceu_coord = coord[ceu_indices].T
	chb_coord = coord[chb_indices].T
	chd_coord = coord[chd_indices].T
	gih_coord = coord[gih_indices].T
	jpt_coord = coord[jpt_indices].T
	lwk_coord = coord[lwk_indices].T
	mex_coord = coord[mex_indices].T
	mkk_coord = coord[mkk_indices].T
	tsi_coord = coord[tsi_indices].T
	yri_coord = coord[yri_indices].T
	plt.scatter(asw_coord[0], asw_coord[1], color='black', label="African ancestry, USA")
	plt.scatter(ceu_coord[0], ceu_coord[1], color='blue', label="European ancestry, Utah")
	plt.scatter(chb_coord[0], chb_coord[1], color='red', label="Chinese, Beijing")
	plt.scatter(chd_coord[0], chd_coord[1], color='pink', label="Chinese, Denver")
	plt.scatter(gih_coord[0], gih_coord[1], color='yellow', label="Gujarati Indians Houston")
	plt.scatter(jpt_coord[0], jpt_coord[1], color='purple', label="Japanese, Tokyo")
	plt.scatter(lwk_coord[0], lwk_coord[1], color='orange', label="Luhya, Kenya")
	plt.scatter(mex_coord[0], mex_coord[1], color='beige', label="Mexican, Los Angeles")
	plt.scatter(mkk_coord[0], mkk_coord[1], color='grey', label="Maasai, Kenya")
	plt.scatter(tsi_coord[0], tsi_coord[1], color='cyan', label="Toscani, Italia")
	plt.scatter(yri_coord[0], yri_coord[1], color='green', label="Yoruba, Nigeria")
	plt.legend(prop={'size':6})
	plt.savefig('isomap_result.png')
	
def run_isomap(data, population_data):
	ismap = Isomap()
	coord = ismap.fit_transform(gene_data)

	load_plot(population_data, coord, "Isomap Embedding")

# =========================== MAIN ===========================
print("\n-- RUNNING ISOMAP --")
print("Reading data..")
gene_data = np.genfromtxt(sys.argv[1], delimiter=",", skip_header=1)[:, 1:]
phen_data = np.genfromtxt(sys.argv[2], delimiter=",", skip_header=1, usecols=[-1])

# =========================== PART 1 ===========================
print("Standarizing data..")
gene_data = preprocessing.scale(gene_data)

split_index = int(gene_data.shape[0] * 0.7)	# Left of this index (70%) is training, right of this (30%) is testing
train_gene = gene_data[:split_index]
train_phen = phen_data[:split_index]

test_gene = gene_data[split_index:]
test_phen = phen_data[split_index:]

# =========================== PART 2 ===========================
print("Computing Isomap..")

run_isomap(gene_data, phen_data)