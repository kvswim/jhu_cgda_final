# Student: Nawaf Al-Dhelaan
# Course: 600.438
# Date: April 7th, 2017

# =========================== Dependencies ===========================

from __future__ import division    # In case you run with python2

from sklearn.decomposition import PCA
from sklearn import preprocessing
import matplotlib.pyplot as plt
import numpy as np
import sys, math

# =========================== Auxilary Functions ===========================
	
# Makes a scatter plot for two PCs. Used in part 3
# I put it in a function to make things neater
def loadings_plot(population_data, PC1, PC2, title):
	# Indices - useful for fast computation
	asw_indices = np.where(population_data == 1)
	ceu_indices = np.where(population_data == 2)
	chb_indices = np.where(population_data == 3)
	chd_indices = np.where(population_data == 4)
	gih_indices = np.where(population_data == 5)
	jpt_indices = np.where(population_data == 6)
	lwk_indices = np.where(population_data == 7)
	mex_indices = np.where(population_data == 8)
	mkk_indices = np.where(population_data == 9)
	tsi_indices = np.where(population_data == 10)
	yri_indices = np.where(population_data == 11)
	n = 11
	colors = 2 * np.pi * np.random.rand(n)
	plt.scatter(PC1[asw_indices], PC2[asw_indices], color='black', label="African ancestry, USA")
	plt.scatter(PC1[ceu_indices], PC2[ceu_indices], color='blue', label="European ancestry, Utah")
	plt.scatter(PC1[chb_indices], PC2[chb_indices], color='red', label="Chinese, Beijing")
	plt.scatter(PC1[chd_indices], PC2[chd_indices], color='pink', label="Chinese, Denver")
	plt.scatter(PC1[gih_indices], PC2[gih_indices], color='yellow', label="Gujarati Indians Houston")
	plt.scatter(PC1[jpt_indices], PC2[jpt_indices], color='purple', label="Japanese, Tokyo")
	plt.scatter(PC1[lwk_indices], PC2[lwk_indices], color='orange', label="Luhya, Kenya")
	plt.scatter(PC1[mex_indices], PC2[mex_indices], color='beige', label="Mexican, Los Angeles")
	plt.scatter(PC1[mkk_indices], PC2[mkk_indices], color='grey', label="Maasai, Kenya")
	plt.scatter(PC1[tsi_indices], PC2[tsi_indices], color='cyan', label="Toscani, Italia")
	plt.scatter(PC1[yri_indices], PC2[yri_indices], color='green', label="Yoruba, Nigeria")
	plt.title(title)
	plt.legend(prop={'size':6})
	plt.savefig("PCA_result.png")
	
def run_pca(data, population_data):
	# Dimensionality reduction over features
	pca = PCA()
	pca.n_components = 20
	X_proj = pca.fit_transform(data)
	pca_loadings = X_proj.transpose()	# transpose for easier indexing

	loadings_plot(population_data, pca_loadings[0], pca_loadings[1], "PC1 loadings vs. PC2 loadings")

# =========================== MAIN ===========================
print("-- RUNNING PCA --")
print("Reading data..")
gene_data = np.genfromtxt(sys.argv[1], delimiter=",", skip_header=1)[:, 1:]
phen_data = np.genfromtxt(sys.argv[2], delimiter=",", skip_header=1, usecols=[-1])

# =========================== PART 1 ===========================
print("Standarizing data..")
gene_data = preprocessing.scale(gene_data)

split_index = int(gene_data.shape[0] * 0.7)	# Left of this index (70%) is training, right of this (30%) is testing
train_gene = gene_data[:split_index]
train_phen = phen_data[:split_index]

test_gene = gene_data[split_index:]
test_phen = phen_data[split_index:]

# =========================== PART 2 ===========================
print("Computing PCAs..")

run_pca(gene_data, phen_data)