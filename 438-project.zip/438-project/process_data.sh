#!/bin/bash

data_dir=$1
results_dir=$2

# Our preprocessing is long and takes time. To make life easier, we've made preprocessed data available at the following link:
# 	https://www.dropbox.com/sh/3kosea55flgz0dm/AABxZJpRITX6qEMaQO6Ti2Hqa?dl=0
# Place the data_genotype.csv and data_phenotype.csv files in the data directory, and you're good to go (no need to run this script).

# If instead you want to download the raw data (~6GB) and run the preprocessing yourself (~1 hr), follow these steps:
# 1. Download the dataset at: ftp://ftp.ncbi.nlm.nih.gov/hapmap/phase_3/hapmap3_r1_b36_fwd.qc.poly.tar.bz2
# 2. Un-tar, and dump all of the files in the data/cleaning_scripts directory.
# 3. Run this script (note you'll need to download PLINK utility tool - if you have homebrew just do "brew install plink")
# 4. The cleaned dataset will be in the data/ directory.

cd $data_dir/cleaning_scripts
sh clean_data.sh 
mv data_*.csv ..