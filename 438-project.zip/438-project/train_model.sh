#!/bin/bash

data_dir=$1
results_dir=$2

# NOTE: The SOM and Autoenoder have dependencies that need to be downloaded.
# The manifold models have everything they need to run on ugrad (sklearn, numpy, and matplotlib)

# ====================== Run SOM ===========================

# Run SOM
# Uncomment the below line to train a new SOM (takes a long time)
#python somoclu-pip.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'
#mv SOM_result.png $results_dir

# ====================== Run Autoencoder ===========================

# Run Autoencoder
# Uncomment the below line to train a new autoencoder (takes a really long time)
#python autoencoder.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'
#mv autoencoder.png $results_dir

# Or, you can download a saved trained autoencoder that you can then load and run to produce the autoencoder diagrams.
# The files containing the saved model, and the parameters, are huge. So we couldn't include them in our email submission.
# The dropbox link: https://www.dropbox.com/sh/q7rwt6os4owblx6/AAA6yJN9uXk2f4ezZllaRwsAa?dl=0
# It contains
#	1. A trained model saved to disk
#	2. Printed parameters in csv files
#	3. Instructions on how to run the autoencoder
# 	4. Diagrams produced by the autoencoder

# ====================== Run Manifold models ===========================

# PCA
python pca_analysis.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'

# Isomap
python isomap_analysis.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'

# MDS
python MDS_analysis.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'

# TSNE
python TSNE_analysis.py $data_dir/'data_genotype.csv' $data_dir/'data_phenotype.csv'
