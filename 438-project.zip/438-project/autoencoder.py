# coding: utf-8

# In[4]:

import numpy as np
import theanets


# In[2]:

# Preprocessing the data
# Copy these steps into your models.

# =========================== Dependencies ===========================

from sklearn import preprocessing
import sys

# =========================== Read in the data ===========================

gene_data = np.genfromtxt(sys.argv[1], delimiter=",", skip_header=1)[:, 1:]
phen_data = np.genfromtxt(sys.argv[2], delimiter=",", skip_header=1, usecols=[-1])

# =========================== Scale the data ===========================

gene_data = preprocessing.scale(gene_data)

# =========================== Split into training, testing ===========================
split_index = int(gene_data.shape[0] * 0.7)	# Left of this index (70%) is training, right of this (30%) is testing
train_gene = gene_data[:split_index]
train_phen = phen_data[:split_index]

test_gene = gene_data[split_index:]
test_phen = phen_data[split_index:]

# In[6]:
layers = [train_gene.shape[1],200,20,2,20,200,train_gene.shape[1]]
model = theanets.Autoencoder(layers)
model.train(train_gene,save_progress={},save_every=15.0)
model.save('autoencoder')
print('Trained!')
###break here if separating into training and testing and uncomment next four lines
#layers = [train_gene.shape[1],200,20,2,20,200,train_gene.shape[1]]
#model = theanets.Autoencoder(layers)
#model.load('autoencoder') #change into 5_layer_autoencoder to load model that was trained with five hidden layers
#print('Loaded!')
for i in range(len(layers)-2):
	title = str(i+1)
	param = model.find('hid'+title,'w')
	values = param.get_value()
	np.savetxt('autoencoder layer ' + title+'.csv',values,delimiter = ',') #saves model parameters as csv files
encode = model.encode(test_gene)
print('Encoding')
# In[7]:
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
def loadings_plot(population_data, PC1, PC2, title):
	# Indices - useful for fast computation
	asw_indices = np.where(population_data == 1)
	ceu_indices = np.where(population_data == 2)
	chb_indices = np.where(population_data == 3)
	chd_indices = np.where(population_data == 4)
	gih_indices = np.where(population_data == 5)
	jpt_indices = np.where(population_data == 6)
	lwk_indices = np.where(population_data == 7)
	mex_indices = np.where(population_data == 8)
	mkk_indices = np.where(population_data == 9)
	tsi_indices = np.where(population_data == 10)
	yri_indices = np.where(population_data == 11)
	n = 11
	colors = 2 * np.pi * np.random.rand(n)
	plt.scatter(PC1[asw_indices], PC2[asw_indices], color='black', label="African ancestry in SW USA")
	plt.scatter(PC1[ceu_indices], PC2[ceu_indices], color='blue', label="Utah residents, NW European ancestry")
	plt.scatter(PC1[chb_indices], PC2[chb_indices], color='red', label="Han Chinese in Beijing, China")
	plt.scatter(PC1[chd_indices], PC2[chd_indices], color='pink', label="Chinese in Metropolitan Denver, Colorado")
	plt.scatter(PC1[gih_indices], PC2[gih_indices], color='yellow', label="Gujarati Indians in Houston, Texas")
	plt.scatter(PC1[jpt_indices], PC2[jpt_indices], color='purple', label="Japanese in Tokyo, Japan")
	plt.scatter(PC1[lwk_indices], PC2[lwk_indices], color='orange', label="Luhya in Webuye, Kenya")
	plt.scatter(PC1[mex_indices], PC2[mex_indices], color='beige', label="Mexican ancestry in Los Angeles, California")
	plt.scatter(PC1[mkk_indices], PC2[mkk_indices], color='grey', label="Maasai in Kinyawa, Kenya")
	plt.scatter(PC1[tsi_indices], PC2[tsi_indices], color='cyan', label="Toscani in Italia")
	plt.scatter(PC1[yri_indices], PC2[yri_indices], color='green', label="Yoruba in Ibadan, Nigeria")
	plt.title(title)
	plt.savefig(title+'.png')

loadings_plot(test_phen,np.transpose(encode)[0],np.transpose(encode)[1],'AutoEncoder')


# In[ ]:



