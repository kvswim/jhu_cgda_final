#!/bin/bash

# Download dependencies
pip install --upgrade pip --user
pip install --user 'somoclu==1.7.2'
pip install --user theano
pip install --user theanets
# for preprocessing - PLINK: http://zzz.bwh.harvard.edu/plink/download.shtml#download