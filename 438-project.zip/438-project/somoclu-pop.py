# Student: Richard Liu
# Course: 600.438 - Final Project
# Date: April 28th, 2017
#
# 	USAGE: python somoclu-pop.py genotype.csv phenotype.csv

# =========================== Dependencies ===========================

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans
import somoclu

# =========================== Main ===========================

geno_data = pd.read_csv(sys.argv[1], delimiter=',').as_matrix()
phen_data = pd.read_csv(sys.argv[2], delimiter=',').as_matrix()

tr_data = geno_data.astype(np.float32)
tr_phen = phen_data[:,1].astype(int)

[n_rows, n_columns] =  tr_data.shape[0]/3, tr_data.shape[0]/3
a = KMeans(n_clusters=4)

colorslist = [None]*len(phen_data)
colors = ['black','blue','red','pink','yellow','purple','orange','beige','grey','cyan','green']

for i in range(len(colorslist)):
    colorslist[i] = colors[tr_phen[i]-1]
    
sompop = somoclu.Somoclu(n_columns, n_rows)
sompop.train(tr_data)
sompop.view_umatrix(bestmatches=True, bestmatchcolors= colorslist )

sompop.cluster(algorithm =a)
sompop.view_umatrix(bestmatches=True, filename="SOM_result.png")
c = sompop.clusters