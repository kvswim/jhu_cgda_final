#!/bin/bash

data_dir=$1
results_dir=$2

# Move files to the results directory; the testing already happens in each of the *_analysis.py files
mv PCA_result.png $results_dir
mv isomap_result.png $results_dir
mv MDS_result.png $results_dir
mv TSNE_result.png $results_dir