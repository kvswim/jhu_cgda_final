# Student: Nawaf Al-Dhelaan
# Course: 600.438 - Final Project
# Date: April 28th, 2017
# Description:
#	Renames files for easier parsing, indexes filenames into allfiles.txt,
#	and indexes phenotypes into phenotypes.txt
#	allfiles.txt and phenotypes.txt are used in the plink command used in the next preprocessing step.
#
# 	USAGE: python prep_merge.py

# =========================== Dependencies ===========================

import os

# =========================== Main ===========================

print("Preparing datasets..")

allfiles = open("allfiles.txt", "w")
phenotypes = open("phenotypes.txt", "w")

ped_files = sorted([f for f in os.listdir() if f.endswith("ped")])
map_files = sorted([f for f in os.listdir() if f.endswith("map")])

for i in range(len(ped_files)):
	# Write phenotypes
	individual_count = 0
	with open(ped_files[i]) as f:
		lines = f.read().splitlines()
		for line in lines:
			if individual_count <= 70:
				line_s = line.split('\t')
				phenotypes.write("%s %s %d\n" % (line_s[0], line_s[1], i+1))
				individual_count += 1
			
	# Index file, and change file naming for easier processing
	population = ped_files[i].split('.')[1]
	os.system("mv %s %s" % (ped_files[i], population+"."+ped_files[i].split('.')[-1]))
	os.system("mv %s %s" % (map_files[i], population+"."+map_files[i].split('.')[-1]))
	if ped_files[i].split('.')[1] != "ASW":
		allfiles.write("%s.ped %s.map\n" % (population, population))	
		
	print("File %d processed\t(%.1f%% complete)" % (i+1, 100*(i+1)/len(ped_files)))
allfiles.close()
phenotypes.close()