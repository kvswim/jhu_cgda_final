#!/bin/bash

# Student: Nawaf Al-Dhelaan
# Course: 600.438 - Final Project
# Date: April 28th, 2017
# Description:
#	Assuming a fresh download of the dataset from the data source, this script produces a cleaned, matrix-styled representation, like the ones used in the homeworks.
#	NOTE: Takes about 1-2 hours to execute (because of the size of the dataset).

# =========================== Step 1: Merge population files into one large data file ===========================
# Prep the data files, produce auxilary files needed for the PLINK function
python3 prep_merge.py 

# Run the PLINK command to reduce datasets for each population based on MAF >= 0.05
for file in *.ped
do
	plink --file "${file%%.*}" --pheno phenotypes.txt --recode --maf 0.05 --out "${file%%.*}" --tab --noweb
done

# Run the PLINK command to merge the reduced datasets together, and then randomly sample 30% of the resulting SNPs
plink --file ASW --merge-list allfiles.txt --pheno phenotypes.txt --recode --geno 0.0 --thin 0.3 --out merged_data --tab --noweb

# =========================== Step 2: Convert format into .csv with MAF encoding ===========================

# Convert file encoding
plink --file merged_data --recodeA --noweb

# Shuffle file
# NOTE: If running on mac os, use gshuf instead of shuf (..need to brew install coreutils)
( head -n 2 plink.raw && tail -n +3 plink.raw | gshuf ) > plink_reordered.raw 

# Convert resulting file into csv format
python3 convert_to_csv.py plink_reordered.raw

# Normalize the csv
#python3 normalize_csv.py data_genotype.csv

# Split into training and testing
#head -700 data_genotype.csv > train_geno.csv
#head -1 data_genotype.csv > test_geno.csv
#tail -415 data_genotype.csv >> test_geno.csv
#
#head -700 data_phenotype.csv > train_phen.csv
#head -1 data_phenotype.csv > test_phen.csv
#tail -415 data_phenotype.csv >> test_phen.csv