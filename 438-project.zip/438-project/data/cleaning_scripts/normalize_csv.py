# Student: Nawaf Al-Dhelaan
# Course: 600.438 - Final Project
# Date: April 28th, 2017
# Description:
#	Standarizes a csv file
#
# 	USAGE: python convert_to_csv $FILE_TO_CONVERT

# =========================== Dependencies ===========================

from sklearn import preprocessing
import numpy as np
import sys

# =========================== Read the data ===========================
print("Standarizing matrix")
full_data = np.genfromtxt(sys.argv[1], delimiter=",", dtype=np.str)
matrix = full_data[1:, 1:].astype(np.float)
matrix = preprocessing.scale(matrix)

full_data[1:, 1:] = matrix
np.savetxt(sys.argv[1], full_data, fmt="%s", delimiter=',')