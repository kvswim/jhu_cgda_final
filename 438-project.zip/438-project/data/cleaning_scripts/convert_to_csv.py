# Student: Nawaf Al-Dhelaan
# Course: 600.438 - Final Project
# Date: April 28th, 2017
# Description:
#	File format conversion; converts a raw PLINK file into genotype.csv and phenotype.csv files
#
# 	USAGE: python convert_to_csv $FILE_TO_CONVERT

# =========================== Dependencies ===========================

import sys

in_f = open(sys.argv[1])
gene_f = open("data_genotype.csv", "w")
phen_f = open("data_phenotype.csv", "w")

header = in_f.readline().strip()
lines = in_f.read().splitlines()
in_f.close()

header = header.split()[6:]
gene_f.write("\"\",%s\n" % (",".join(header)))
phen_f.write("%s,%s\n" % ("Individual", "Population"))

for line in lines:
	line_s = line.split()
	if int(line_s[5]) != -9:
		gene_f.write("%s,%s\n" % (line_s[1], ",".join(line_s[6:])))
		phen_f.write("%s,%s\n" % (line_s[1], line_s[5]))
	
gene_f.close()
phen_f.close()